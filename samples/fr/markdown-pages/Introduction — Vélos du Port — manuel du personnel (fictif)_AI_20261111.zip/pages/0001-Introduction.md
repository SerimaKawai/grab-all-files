# Introduction

> source_url: https://grab-all-files.app/samples/source/fr/bike-share-handbook/index.html
> captured_at: 2026-11-11T00:09:15.220Z
> page_id: p00001

## Introduction

Ce manuel décrit le travail quotidien dans une station de Vélos du Port. Vélos du Port est un service fictif créé pour le guide de Grab All Files.

Lisez les chapitres dans l’ordre pendant votre première semaine. Chaque chapitre se termine par une courte liste de contrôle.

1. [Ouvrir une station](https://grab-all-files.app/samples/source/fr/bike-share-handbook/chapter-1.html)
2. [Traiter un signalement de réparation](https://grab-all-files.app/samples/source/fr/bike-share-handbook/chapter-2.html)
3. [Clôturer la journée](https://grab-all-files.app/samples/source/fr/bike-share-handbook/chapter-3.html)
