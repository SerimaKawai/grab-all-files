# Introducción

> source_url: https://grab-all-files.app/samples/source/es/bike-share-handbook/index.html
> captured_at: 2026-10-21T03:16:53.886Z
> page_id: p00001

#### Introducción

Este manual explica el trabajo diario en una estación de Bici Puerto. Bici Puerto es un servicio ficticio creado para la guía de Grab All Files.

Lea los capítulos en orden durante la primera semana. Cada capítulo termina con una lista de comprobación breve.

1. [Abrir una estación](https://grab-all-files.app/samples/source/es/bike-share-handbook/chapter-1.html)
2. [Atender un aviso de reparación](https://grab-all-files.app/samples/source/es/bike-share-handbook/chapter-2.html)
3. [Cerrar la jornada](https://grab-all-files.app/samples/source/es/bike-share-handbook/chapter-3.html)
