# Introduzione

> source_url: https://grab-all-files.app/samples/source/it/bike-share-handbook/index.html
> captured_at: 2026-10-27T23:21:28.946Z
> page_id: p00001

#### Introduzione

Questo manuale descrive il lavoro quotidiano in una stazione di Porto in Bici. Porto in Bici è un servizio immaginario creato per la guida di Grab All Files.

Nella prima settimana leggi i capitoli in ordine. Ogni capitolo termina con una breve lista di controllo.

1. [Apertura di una stazione](https://grab-all-files.app/samples/source/it/bike-share-handbook/chapter-1.html)
2. [Gestione di una segnalazione di guasto](https://grab-all-files.app/samples/source/it/bike-share-handbook/chapter-2.html)
3. [Chiusura della giornata](https://grab-all-files.app/samples/source/it/bike-share-handbook/chapter-3.html)
