# Introdução

> source_url: https://grab-all-files.app/samples/source/pt_BR/bike-share-handbook/index.html
> captured_at: 2026-11-11T00:10:58.310Z
> page_id: p00001

## Introdução

Este manual explica o trabalho diário em uma estação das Bicicletas do Porto. As Bicicletas do Porto são um serviço fictício criado para o guia do Grab All Files.

Leia os capítulos em ordem na primeira semana. Cada capítulo termina com uma lista de conferência curta.

1. [Abrir uma estação](https://grab-all-files.app/samples/source/pt_BR/bike-share-handbook/chapter-1.html)
2. [Tratar um relato de defeito](https://grab-all-files.app/samples/source/pt_BR/bike-share-handbook/chapter-2.html)
3. [Encerrar o dia](https://grab-all-files.app/samples/source/pt_BR/bike-share-handbook/chapter-3.html)
